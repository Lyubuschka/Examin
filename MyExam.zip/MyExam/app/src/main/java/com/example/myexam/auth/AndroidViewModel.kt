package com.example.myexam.auth

class AndroidViewModel {
}