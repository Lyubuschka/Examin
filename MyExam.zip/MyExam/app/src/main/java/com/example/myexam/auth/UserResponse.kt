package com.example.myexam.auth

data class UserResponse (val email: String, val username: String)