package com.example.myexam.auth


import retrofit2.http.GET
import retrofit2.Call


interface UserService {
    @GET("/users")
    fun getAll(): Call<List<UserResponse>>
}